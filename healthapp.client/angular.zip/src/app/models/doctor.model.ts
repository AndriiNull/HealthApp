export interface Doctor {
  id: number;
  name: string;
  surname: string;
  gender: string;
  licenseExpiration: Date;
}
