import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css'],
  standalone: true,
  imports: [CommonModule, RouterModule] // ✅ Ensure RouterModule is imported
})
export class SidebarComponent {
  @Output() toggle = new EventEmitter<void>();
  isCollapsed = false;

  menuItems = [
    { label: 'Dashboard', link: '/dashboard' },
    { label: 'About Us', link: '/about' },
    { label: 'Doctors', link: '/doctors' },
    { label: 'Patients', link: '/patients' },
    { label: 'Appointments', link: '/appointments' },
    { label: 'Issues', link: '/issues' }
  ];

  constructor(private authService: AuthService, private router: Router) { }

  toggleSidebar() {
    this.isCollapsed = !this.isCollapsed;
    this.toggle.emit();
  }

  isLoggedIn(): boolean {
    return this.authService.isLoggedIn();
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
