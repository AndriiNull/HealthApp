import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';  // ✅ Import FormsModule
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule] // ✅ Add FormsModule
})
export class RegisterComponent {
  name = '';
  surname = '';
  email = '';
  password = '';
  errorMessage = '';

  constructor(private authService: AuthService, private router: Router) { }

  register() {
    if (!this.name || !this.surname || !this.email || !this.password) {
      this.errorMessage = 'All fields are required.';
      return;
    }

    this.authService.register(this.name, this.surname, this.email, this.password).subscribe({
      next: () => {
        console.log('Registration successful');
        this.router.navigate(['/login']); // ✅ Redirect to login after success
      },
      error: (err) => {
        console.error('Registration failed:', err);
        this.errorMessage = 'Registration failed. Try again.';
      }
    });
  }
}
