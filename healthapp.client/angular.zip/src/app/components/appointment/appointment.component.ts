import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

// ✅ Import Angular Material Modules
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';

import { DoctorService } from '../../services/doctors.service';
import { AppointmentService } from '../../services/appointment.service';

@Component({
  selector: 'app-appointments',
  standalone: true,
  imports: [
    CommonModule, RouterModule, FormsModule,

    // ✅ Include Material Modules
    MatFormFieldModule, MatSelectModule, MatDatepickerModule, MatNativeDateModule, MatInputModule, MatButtonModule
  ],
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.css']
})
export class AppointmentsComponent implements OnInit {
  doctors: any[] = [];
  doctorId: number | null = null;
  doctor: any = null;
  availableSlots: { [key: string]: string[] } = {}; // ✅ Store slots per date
  selectedSlot: string | null = null;
  selectedDate: string = ''; // ✅ Ensure selectedDate is always a string
  step: number = 1;
  doctorLicenses: string = '';

  constructor(
    private appointmentService: AppointmentService,
    private doctorService: DoctorService
  ) { }

  ngOnInit(): void {
    this.loadDoctors();
  }

  loadDoctors() {
    this.doctorService.getAllDoctors().subscribe({
      next: (data) => { this.doctors = data; },
      error: (error) => console.error('Error fetching doctors', error)
    });
  }

  selectDoctor() {
    console.log("Before selection, doctorId:", this.doctorId);

    if (this.doctorId !== null && this.doctorId !== undefined) {
      const selectedDoctorId = Number(this.doctorId); // ✅ Ensure it's a number
      console.log("Converted doctorId:", selectedDoctorId);

      this.doctor = this.doctors.find(d => d.doctorId === selectedDoctorId) || null;

      if (this.doctor) {
        console.log("Doctor Found:", this.doctor);
        this.doctorLicenses = this.doctor.activeLicenses?.map((l: any) => l.practiceName).join(', ') || 'No Licenses';
        this.step = 2;
      } else {
        console.warn("❌ Doctor not found!");
      }
    } else {
      console.warn("❌ Invalid doctorId received!");
    }
  }

  selectDate(event: any) {
    if (!event || !event.value) {
      console.warn("❌ Date selection event is invalid:", event);
      return;
    }

    const date = event.value as Date;
    console.log("✅ Date selected:", date);

    this.selectedDate = new Intl.DateTimeFormat('en-US').format(date); // Convert to YYYY-MM-DD
    this.loadAvailableSlots();
  }

  loadAvailableSlots() {
    if (!this.doctorId)
      alert(2);
    if (!this.selectedDate)
      alert(3);
    if (!this.doctorId || !this.selectedDate) {
      alert(1);
      return;
    }
    
    this.appointmentService.getAvailableSlots(this.doctorId, this.selectedDate).subscribe({
      next: (slots) => {
        this.availableSlots[this.selectedDate] = slots;
      },
      error: (error) => console.error('Error fetching slots', error)
    });

    this.step = 3; // ✅ Proceed to the next step
  }

  selectSlot(slot: string) {
    this.selectedSlot = slot;
    this.step = 4;
  }

  goBack() {
    if (this.step > 1) this.step--;
  }

  bookAppointment() {
    if (!this.doctorId || !this.selectedSlot) return;
    const appointmentData = { doctorId: this.doctorId, startTime: this.selectedSlot };

    this.appointmentService.bookAppointment(appointmentData).subscribe({
      next: (response) => {
        console.log('Appointment booked:', response);
        alert('✅ Appointment successfully booked!');
      },
      error: (error) => console.error('❌ Error booking appointment', error)
    });
  }

  formatSlot(slot: string): string {
    const date = new Date(slot);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
  }
}
