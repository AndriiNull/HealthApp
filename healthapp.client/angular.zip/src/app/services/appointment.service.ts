import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {
  private apiUrl = '/api/Appointment';
  
  constructor(private http: HttpClient) { }

  getAvailableDates(doctorId: number): Observable<string[]> {
    return this.http.get<string[]>(`${this.apiUrl}/available-dates/${doctorId}`);
  }

  getAvailableSlots(doctorId: number, date: string): Observable<string[]> {
    const formattedDate = new Date(date).toLocaleDateString('en-US'); // ✅ Convert to MM/DD/YYYY
    const encodedDate = encodeURIComponent(formattedDate); // ✅ Encode properly

    console.log(`Formatted Date: ${formattedDate}`); // Debugging
    console.log(`Encoded Date: ${encodedDate}`); // Debugging

    return this.http.get<string[]>(`${this.apiUrl}/availableSlots/${doctorId}?date=${encodedDate}`);
  }


  bookAppointment(appointmentData: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/book`, appointmentData);
  }
}
