import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = '/api/Auth'; // ✅ Set API base URL

  constructor(private http: HttpClient) { }

  /** ✅ Login (with API call) */
  login(credentials: { email: string; password: string }): Observable<{ token: string; role: string }> {
    return this.http.post<{ token: string; role: string }>(`${this.apiUrl}/login`, credentials).pipe(
      tap(response => {
        localStorage.setItem('token', response.token);
        localStorage.setItem('role', response.role);
      })
    );
  }

  /** ✅ Register a New Patient */
  register(name: string, surname: string, email: string, password: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/register`, { name, surname, email, password });
  }

  /** ✅ Logout */
  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
  }

  /** ✅ Check if user is logged in */
  isLoggedIn(): boolean {
    return !!localStorage.getItem('token');
  }

  /** ✅ Retrieve User Role */
  getUserRole(): string | null {
    return localStorage.getItem('role');
  }

  /** ✅ Check Role-Based Access */
  hasRole(requiredRoles: string[]): boolean {
    const userRole = this.getUserRole();
    return userRole ? requiredRoles.includes(userRole) : false;
  }

  /** ✅ Get JWT Token for Authenticated Requests */
  getToken(): string | null {
    return localStorage.getItem('token');
  }
}
